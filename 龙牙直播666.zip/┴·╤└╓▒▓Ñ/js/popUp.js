function popUp(para={}){   
	let that = this;
	let initial = {
		isShow: false,
		isShowBg : false,
		classNameBox: "popUpBoxs",
		classNameBg: "popUpBoxsBg",
		// login: false,
		// register: false,
		// modifyPhone: false,
		// changePassword: false,
		// forgetPassword: false,
		...para
	};
	const initDiv={
		login:`<div class="login popUpBoxs"><div class="cenBox"><div class="cenBoxTit"><div class="cenBoxTit_Tab"><span data-class="login_pass">帐号密码登录</span><span data-class="login_yzms">手机验证码登录</span></div><div class="cenBoxTit_Col"><img src="images/s_close.png" /></div></div><div class="cenBoxMan login_pass"><div class="cenBoxMan_Inp"><input type="text" class="Inp_a" value="+86"/><input type="text" class="Inp_b" placeholder="请输入手机号码"/></div><div class="cenBoxMan_Inp"><input type="t" class="Inp_c" placeholder="请输入密码"/></div><div class="cenBoxMan_Bnt"><button type="button">登录</button></div></div><div class="cenBoxMan login_yzms"><div class="cenBoxMan_Inp"><input type="text" class="Inp_a" value="+86"/><input type="text" class="Inp_b" placeholder="请输入手机号码"/></div><div class="cenBoxMan_Inp"><input type="text" class="Inp_d" placeholder="请输入短信验证码"/><input type="submit" class="Inp_e" value="获取验证码"/></div><div class="cenBoxMan_Bnt"><button type="button">登录</button></div></div><div class="cenBoxFot"><span class="goRegister red">我要注册</span><span class="goForPass">忘记密码</span></div></div><div class="popUpBoxsBg"></div></div>`,
		register:`<div class="register popUpBoxs"><div class="cenBox"><div class="cenBoxTit"><div class="cenBoxTit_Tab"><span data-class="register">快速注册</span></div><div class="cenBoxTit_Col"><img src="images/s_close.png" /></div></div><div class="cenBoxMan"><div class="cenBoxMan_Inp"><input type="text" class="Inp_a" value="+86"/><input type="text" class="Inp_b" placeholder="请输入手机号码"/></div><div class="cenBoxMan_Inp"><input type="text" class="Inp_d" placeholder="请输入短信验证码"/><input type="submit" class="Inp_e" value="获取验证码"/></div><div class="cenBoxMan_Inp"><input type="password" class="Inp_c" placeholder="请输入密码"/></div><div class="cenBoxMan_Bnt"><button type="button">注册登录</button></div></div></div><div class="popUpBoxsBg"></div></div>`,
		modifyPhone:`<div class="modifyPhone popUpBoxs"><div class="cenBox"><div class="cenBoxTit"><div class="cenBoxTit_Tab"><span data-class="register">修改手机号码</span></div><div class="cenBoxTit_Col"><img src="images/s_close.png" /></div></div><div class="cenBoxMan oldPhone"><div class="cenBoxMan_Cal"><span>当前手机：<i>15888888888</i></span></div><div class="cenBoxMan_Inp"><input type="text" class="Inp_d" placeholder="请输入短信验证码"/><input type="submit" class="Inp_e" value="获取验证码"/></div><div class="cenBoxMan_Bnt"><button type="button" class="stepNext">下一步</button></div><div class="cenBoxMan_Pst"><span>*修改手机绑定成功后，请用<i>新手机号</i>和<i>原密码</i>登录</span></div></div><div class="cenBoxMan newPhone"><div class="cenBoxMan_Inp"><input type="text" class="Inp_a" value="+86"/><input type="text" class="Inp_b" placeholder="请输入手机号码"/></div><div class="cenBoxMan_Inp"><input type="text" class="Inp_d" placeholder="请输入短信验证码"/><input type="submit" class="Inp_e" value="获取验证码"/></div><div class="cenBoxMan_Bnt"><button type="button">提交</button></div><div class="cenBoxMan_Pst"><span>*修改手机绑定成功后，请用<i>新手机号</i>和<i>原密码</i>登录</span></div></div></div><div class="popUpBoxsBg"></div></div>`,
		changePassword:`<div class="changePassword popUpBoxs"><div class="cenBox"><div class="cenBoxTit"><div class="cenBoxTit_Tab"><span data-class="register">修改密码</span></div><div class="cenBoxTit_Col"><img src="images/s_close.png" /></div></div><div class="cenBoxMan"><div class="cenBoxMan_Inp"><input type="password" class="Inp_c" placeholder="请输入旧密码"/></div><div class="cenBoxMan_Inp"><input type="password" class="Inp_c" placeholder="请输入6-20位字母数字组合密码"/></div><div class="cenBoxMan_Inp"><input type="password" class="Inp_c" placeholder="请再次输入6-20位字母数字组合密码"/></div><div class="cenBoxMan_Bnt"><button type="button">提交</button></div></div></div>	<div class="popUpBoxsBg"></div></div>`,
		forgetPassword:`<div class="forgetPassword popUpBoxs"><div class="cenBox"><div class="cenBoxTit"><div class="cenBoxTit_Tab"><span data-class="register">忘记密码</span></div><div class="cenBoxTit_Col"><img src="images/s_close.png" /></div></div><div class="cenBoxMan"><div class="cenBoxMan_Inp"><input type="text" class="Inp_a" value="+86"/><input type="text" class="Inp_b" placeholder="请输入手机号码"/></div><div class="cenBoxMan_Inp"><input type="text" class="Inp_d" placeholder="请输入短信验证码"/><input type="submit" class="Inp_e" value="获取验证码"/></div><div class="cenBoxMan_Inp"><input type="password" class="Inp_c" placeholder="请输入新密码"/></div><div class="cenBoxMan_Inp"><input type="password" class="Inp_c" placeholder="请再次输入新密码"/></div><div class="cenBoxMan_Bnt"><button type="button">提交</button></div></div></div><div class="popUpBoxsBg"></div></div>`,
	}
	
	that.initPopUp = function() {//初始化弹窗
		$(initial.classNameBox).addClass(initial.isShow?'showOn':'hideOn');
	}
	
	that.initHtml = function() {//初始化弹窗内容
		$('body').append(initDiv.login);
		$('body').append(initDiv.register);
		$('body').append(initDiv.modifyPhone);
		$('body').append(initDiv.changePassword);
		$('body').append(initDiv.forgetPassword);
	}
	//弹窗显示
	that.show = function(el){
		initial.isShow= true;
		$(el).addClass('showOn').removeClass('hideOn');
	};
	that.hide = function(el){
		initial.isShow= false;
		$(el).addClass('hideOn').removeClass('showOn');
	};
	
	//登录注册忘记修改密码
	that.login=function (el){
		$(el + ' .cenBoxMan').eq(0).show();
		$(el + ' .cenBoxTit_Tab>span').eq(0).addClass('on');
		$(el + ' .cenBoxTit_Col').on('click',function(){
			that.hide(el);
		})
		$(el + ' .cenBoxTit_Tab>span').on('click',function(){
			const cls=$(this).attr('data-class');
			$(this).addClass('on').siblings('span').removeClass('on');
			$(`.${cls}`).show().siblings('.cenBoxMan').hide();
		})
		$(el + ' .goRegister').on('click',function(){
			that.hide(el);
			that.show('.register');
		})
		$(el + ' .goForPass').on('click',function(){
			that.hide(el);
			that.show('.forgetPassword');
		})
	}
	that.register=function(el){
		$(el + ' .cenBoxMan').show();
		$(el + ' .cenBoxTit_Tab>span').eq(0).addClass('on');
		$(el + ' .cenBoxTit_Col').on('click',function(){
			that.hide(el);
		})
	}
	that.modifyPhone=function(el){
		$(el + ' .cenBoxMan').eq(0).show();
		$(el + ' .cenBoxTit_Tab>span').eq(0).addClass('on');
		$(el + ' .cenBoxTit_Col').on('click',function(){
			that.hide(el);
		})
		$(el + ' .stepNext').on('click',function(){
			$(el + ' .newPhone').show().siblings('.oldPhone').hide();
		})
	}
	that.changePassword=function(el){
		$(el + ' .cenBoxMan').show();
		$(el + ' .cenBoxTit_Tab>span').eq(0).addClass('on');
		$(el + ' .cenBoxTit_Col').on('click',function(){
			that.hide(el);
		})
	}
	that.forgetPassword=function(el){
		$(el + ' .cenBoxMan').show();
		$(el + ' .cenBoxTit_Tab>span').addClass('on');
		$(el + ' .cenBoxTit_Col').on('click',function(){
			that.hide(el);
		})
		$(el + ' .stepNext').on('click',function(){
			$(el + ' .newPhone').show().siblings('.oldPhone').hide();
		})
	}
	
	that.initHtml();
	that.initPopUp();
	that.login('.login');
	that.register('.register');
	that.modifyPhone('.modifyPhone');
	that.changePassword('.changePassword');
	that.forgetPassword('.forgetPassword');
}
function prompt(){
	let that = this;
	let initial = {
		isShow: false,
		time: 2000,
	};
	const initDiv={
		promptSuccess:`<div class="prompt promptSuccess"><div class="prompt_Success"><span><img src="images/s_succe.png" ><i></i></span></div><div class="prompt_Bg"></div></div>`,
		promptError:`<div class="prompt promptError"><div class="prompt_Error"><span><img src="images/s_error.png" ><i></i></span><button type="button">确定</button></div><div class="prompt_Bg"></div></div>`
	}
	$('body').append(initDiv.promptSuccess);
	$('body').append(initDiv.promptError);
	that.showSuccess=function(m,t=2000){
		$('.prompt_Success i').html(m?m:'');
		$('.promptSuccess').removeClass('hideOn').addClass('showOn');
		setTimeout(function(){
			that.clearSuccess();
		},t)
	}
	that.clearSuccess=function(){
		$('.prompt_Success i').html('');
		$('.promptSuccess').removeClass('showOn').addClass('hideOn');
	}
	
	that.showError=function(m){
		$('.prompt_Error i').html(m?m:'');
		$('.promptError').removeClass('hideOn').addClass('showOn');
		$('.prompt_Error button').on('click',function(){
			that.clearError();
		})
	}
	that.clearError=function(){
		$('.prompt_Error i').html('');
		$('.promptError').removeClass('showOn').addClass('hideOn');
	}
}
const point = new prompt();
const onpopUp = new popUp();

window.onload = function() {
	//提示弹窗
	$('.bnt5').on('click', function() {
		point.showSuccess('验证码已发送',2000);
	});
	$('.bnt6').on('click', function() {
		point.showError('请输入完整信息');
	});
	//事件可以对应类ID自己加
	$('.header .sign').on('click', function() {
		onpopUp.show('.login');
	});
	$('.bnt2').on('click', function() {
		onpopUp.show('.register');//单独注册
	});
	$('#xgCall').on('click', function() {
		onpopUp.show('.modifyPhone');
	});
	$('#xgPass').on('click', function() {
		onpopUp.show('.changePassword');
	});
}
