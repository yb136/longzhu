var isLoginSuccess = false;
var username;
var nickname;
var password;
var userimg;
var manageurl = "http://admin.lyzb88.com/";
var aroomsurl = "http://member.lyzb88.com/";
var contentUlr = "http://www.lyzb8.net";
function none() { }
    // 页面初始化方法
function initFunc(method) {
    // 手机浏览转向手机页面
    var userAgentInfo = window.navigator.userAgent;
    userAgentInfo = userAgentInfo.toLowerCase();
    if (userAgentInfo.indexOf("iphone") > -1 ||
        (userAgentInfo.indexOf("android") > -1 || userAgentInfo.indexOf("adr") > -1 || userAgentInfo.indexOf("linux") > -1
            || userAgentInfo.indexOf("ucbrowser") > -1 && userAgentInfo.indexOf("windows") > -1)
    ) {
        window.location.href = "http://www.360jrs.net/web/index.html";
    }
    downLoad();
    setWidth();

    $("#login_logon").empty().load("./login.html", function () {
        // 进入页面读取cookie自动登录
        initLogin(method);
        // 登录部分div显示隐藏
        loginModelHover();

    });
}

// 进入页面读取cookie自动登录
function initLogin(method) {
    username = getCookie("longya_username");
    nickname = getCookie("longya_nickname");
    password = getCookie("longya_password");
    userimg = getCookie("longya_img");
    $.ajax({
        url:contentUlr + "/AjaxServer/ServerAjaxData.aspx",
        type: "POST",
        loading: true,
        dataType: "json",
        data: {
            action: "cookieLogin",
            username: username,
            password: password
        },
        success: function (json) {
            if (json.success) {
                var item = json.message[0];
                loginSucess(item);
                isLoginSuccess = true;
            } else {
                isLoginSuccess = false;
            }
            method();
        },
        error: function (e) {
            isLoginSuccess = false;
        }

    });
}

function logon() {
    var uname = $("#logon input.ipt[name=phoneNum]").val();
    var upwd = $("#logon input.ipt[name=password]").val();
    var unick = $("#logon input.ipt[name=nickname]").val();
    var uVCode = $("#logon #yzphonenum").val();
    
    if (!loFormat(uname, upwd)) return;
    if (unick === undefined || unick === null || unick === "") {
        layer.msg("昵称不能为空！");
        return;
    }

    if (uVCode === "" || parseInt(uVCode) > 9999 && parseInt(uVCode) < 1000 || !isVCode) {
        layer.msg("验证码错误！");
        return;
    }

    var protocol = $("#logon .loginbox-protocol input[name=protocol]").prop("checked");
    if (!protocol) {
        layer.msg('请先阅读并同意条款！');
        return;
    }
    $.ajax({
        url: contentUlr + "/AjaxServer/ServerAjaxData.aspx",
        type: "POST",
        loading: true,
        dataType: "json",
        data: {
            action: "logon",
            username: uname,
            password: upwd,
            nickname: unick,
            vCode: uVCode
            //validateCode: validateCode
        },
        success: function (json) {

            if (json.success) {
                $("#logon").hide();
                $("#login").show();
                $("#logon input.opt").val("");
                layer.msg("注册成功!请登录！");
            } else {
                layer.msg(json.message);
            }

        },
        error: function (e) {}
    });
}

function login() {
    var uname = $("#login input.ipt[name=phoneNum]").val();
    var upwd = $("#login input.ipt[name=password]").val();
    if (!loFormat(uname, upwd)) return;
    $.ajax({
        url: contentUlr + "/AjaxServer/ServerAjaxData.aspx",
        type: "POST",
        loading: true,
        dataType: "json",
        data: {
            action: "login",
            username: uname,
            password: upwd
        },
        success: function (json) {
            if (json.success) {
                var item = json.message[0];
                loginSucess(item);
                window.location.reload();
            } else {
                layer.msg(json.message);
            }
        },
        error: function (e) {
        }
    });
}

function loFormat(uname, upwd) {
    var result = false;
    //var unameFrm = /^[a-zA-Z0-9]{4,16}$/;
    var unameFrm = /^1[3456789]\d{9}$/;
    if (!unameFrm.test(uname)) {
        //layer.alert("账号格式不正确!\n4-16位,非特殊字符！");
        layer.alert("手机号有误！");
        return result;
    }
    var upwdFrm = /^.*(?=.{6,18})(?=.*\d)(?=.*[a-zA-Z]).*$/;
    //var a = /^\([a-zA-Z\d]{0,16}(([a-zA-Z]\d)|(\d[a-zA-Z]))+)|((([a-zA-Z]\d)|(\d[a-zA-Z]))+[a-zA-Z\d]{0,16})$/;
    if (!upwdFrm.test(upwd)) {
        layer.alert("密码格式不正确!\n6-18位,字母和数字的组合！");
        return result;
    }
    return true;
}


// 登录成功之后
function loginSucess(item) {
    var img = userimg;
    if (item !== undefined) {
        setCookie("longya_username", item.t_username);
        setCookie("longya_nickname", item.t_nickname);
        setCookie("longya_password", item.t_pwd);
        setCookie("longya_img", item.t_img);
        img = item.t_img;
    }

    var html = loginSuccessDiv();
    $(".UnLogin .public-DropMenu").append(html);
    //$(".UnLogin .UnLogin-img").addClass("lylogo");
    $(".UnLogin .UnLogin-img").css("background-image", "url(" + img + ")");
    //$(".UnLogin .UnLogin-icon").removeClass("UnLogin-icon");
}

function logout() {
    $.ajax({
        url: contentUlr + "/AjaxServer/ServerAjaxData.aspx",
        type: "POST",
        loading: true,
        //dataType: "json",
        data: {
            action: "logout"
        },
        success: function (json) {
            setCookie("longya_username", "");
            setCookie("longya_nickname", "");
            setCookie("longya_password", "");
            setCookie("longya_img", "");
            window.location.reload();
        },
        error: function (e) {}
    });
}

var cityip = ",";
$.ajax({
    url: contentUlr + "https://2020.ipchaxun.com/",
    type: "POST",
    loading: true,
    dataType: "json",
    success: function (json) {
        //console.log(json);
        cityip = json.ip + "," + json.data[0] + json.data[1] + json.data[2] + json.data[3];
    },
    error: function (result) {
        //exception_handling();
    }
});

var isVCode = false;        // 是否成功获得验证码
function getPhoneVCode(dom, phone) {
    var d = $(dom);
    if (d.prop("disabled")) {
        return;
    }
    if (phone === "" || phone === undefined || !phoneRegex(phone)) {
        return;
    }
    var ip = ",";
    try {
        ip = returnCitySN["cip"] + ',' + returnCitySN["cname"];
    } catch (e) {
        ip = cityip;
    }
    var ips = ip.split(",");
    $.ajax({
        url: contentUlr + "/AjaxServer/ServerAjaxData.aspx",
        type: "POST",
        loading: true,
        dataType: "json",
        data: {
            action: "getPhoneVCode",
            phone: phone,
            uip: ips[0],
            addr: ips[1]
        },
        success: function (json) {
            d.css({ "background": "gray", "disabled": true }).removeAttr("onclick").text("已发送").attr("value", "已发送");;
            if (json.success) {
                isVCode = true;
            } else {
                isVCode = false;
            }
            isVCode = true;
        },
        error: function (e) {

        }

    });
}

function phoneRegex(phone) {
    var unameFrm = /^1[3456789]\d{9}$/;
    if (!unameFrm.test(phone)) {
        layui.use('layer', function () {
            var layer = layui.layer;
            layer.alert("手机号有误！");
        });
        return false;
    }
    return true;
}

function downLoad() {
    $(".Header-download-wrap .Download").click(function () {
        clickDown();
    });
}

function clickDown() {
    var userAgentInfo = window.navigator.userAgent;
    userAgentInfo = userAgentInfo.toLowerCase();
    if (userAgentInfo.indexOf("iphone") > -1) {
        // 苹果
        window.location.href = "../papp/download.html";
    }
    if (userAgentInfo.indexOf("android") > -1 || userAgentInfo.indexOf("adr") > -1 || userAgentInfo.indexOf("linux") > -1
        || userAgentInfo.indexOf("ucbrowser") > -1 && userAgentInfo.indexOf("windows") > -1) {
        // 安卓
        window.location.href = "../papp/longya.apk";
    }
    if (userAgentInfo.indexOf("windows") > -1 && userAgentInfo.indexOf("ucbrowser") < 0) {
        // 电脑  弹二维码框

        $("#login").hide();
        $("#logon").hide();
        $("#down").show();
        $("#shadow").show();


        //window.location.href = "../papp/longya.apk";
    }
}

function setWidth() {
    var w = parseInt(screen.width);
    if (w < 1400) {
        $(".layout-Main:not(.no_Margin)").css("margin-left", 0);
    }
}


function getVideoInfo(funcMethod, action, bigNo, d) {

    $.ajax({
        url: contentUlr + "/AjaxServer/ServerAjaxData.aspx",
        type: "POST",
        loading: true,
        dataType: "json",
        data: {
            action: action,
            bigNo: bigNo
        },
        success: function (json) {
            funcMethod(json, d);
        },
        error: function (e) {

        }

    });
}

function liveWindow(rno, genre, liveImg, userImg, title, userName, hotNum) {
    var html = '';
    html += '<li>';
    html +='<a href="./live.html?live=' + rno + '" title="' + title + '">';
    html +='<div class="pic">';  
    html +='<img src="' + liveImg + '" alt=""></img>';
    html +='<span>' + genre + '</span>';
    html += '</div>';
    html +='<div class="info">';
    html +='<div class="info">';
    html +='<span class="icon"></span>';
    html +='<img src="' + userImg + ' " alt="">';
    html +='</span>';
    html +='<div>';
    html +='<p class="title">' + title + '</p>';
    html +='<p class="nig">';
    html +='<span>' + userName + '</span>';
    html +='<em>' + hotNum + '</em>';
    html +='</p>';
    html +='</div>';
    html +='</a>';
    html +='</div>';
    html +='</li>';
    return html;
}

function channelListWindow(rno, genre, liveImg, userImg, title, userName, hotNum) {
    var html = '';
    html += '<li>';
    html +='<a href="./live.html?live=' + rno + '" title="' + title + '">';
    html +='<div class="pic">';  
    html +='<img src="' + liveImg + '" alt=""></img>';
    html +='<span>' + genre + '</span>';
    html += '</div>';
    html +='<div class="info">';
    html +='<div class="info">';
    html +='<span class="icon"></span>';
    html +='<img src="' + userImg + ' " alt="">';
    html +='</span>';
    html +='<div>';
    html +='<p class="title">' + title + '</p>';
    html +='<p class="nig">';
    html +='<span>' + userName + '</span>';
    html +='<em>' + hotNum + '</em>';
    html +='</p>';
    html +='</div>';
    html +='</a>';
    html +='</div>';
    html +='</li>';
    return html;
}

// 页面右上角头像位置点击
function headClick() {
    // 登录了转向用户中心，未登录显示登录窗口
    if (isLoginSuccess) {
        window.open("../user.html", "_blank");
    } else {
        $("#login").show();
        $("#logon").hide();
        $("#down").hide();
        $("#shadow").show();
    }
}

// 登录部分div显示隐藏
function loginModelHover() {

    //鼠标移动显示隐藏登录、注册引导窗口
    $(".UnLogin,.Follow").hover(function () {
        $(this).children().addClass("is-hover");
    }, function () {
        $(this).children().removeClass("is-hover");
        });

    // 登录、注册窗口
    $(".UnLogin .UnLogin-btn").click(function () {
        var index = $(this).index();
        if (index === 2) {
            // 登录
            $("#login").show();
            $("#logon").hide();
            $("#down").hide();
            $("#shadow").show();

        } else if (index === 3) {
            // 注册
            $("#login").hide();
            $("#logon").show();
            $("#down").hide();
            $("#shadow").show();
        }
    });

    // 关闭登录、注册窗口
    $(".loginbox-close").click(function () {
        $("#login").hide();
        $("#logon").hide();
        $("#shadow").hide();
    });

    // 搜索框点击变长 
    $("#header-search-input").focus(function () {
        $(this).parent().addClass("is-hover");
    });
    $("#header-search-input").blur(function () {
        $(this).parent().removeClass("is-hover");
    });

    // 搜索
    $("#header-search-input").next().click(function () {
        var v = encodeURI(encodeURI($("#header-search-input").val()));
        var t = getQueryString("t");
        if (t !== "y") {
            window.open("../search.html?v=" + v, "_blank");
        } else {
            window.open("../search.html?t=y&v=" + v, "_self");
        }
    });

}




function loginSuccessDiv() {
    var html = '';
    html += '<div class="Header-UserPane public-DropMenu-drop">';
    html += '<div class="public-DropMenu-drop-main">';
    html += '<i></i>';
    html += '<div class="Header-UserPane-top">';
    html += '<div class="User">';
    html += '<div class="User-avatarWrap">';
    html += '<a class="User-avatar" href="./user.html" target="_blank">';
    html += '<div style="width: 100%;">';
    html += '<div class="Avatar is-circle">';
    html += '<img class="Avatar-img" src="' + userimg + '" onerror="this.src=\'../image/longya.png\'" alt="">';
    html += '</div>';
    html += '</div>';
    html += '</a>';
    html += '</div>';
    html += '<div class="User-nickname">';
    html += '<a href="./user.html" target="_blank" title="' + nickname + '">' + nickname + '</a>';
    html += '</div>';
    html += '</div>';
    html += '</div>';
    html += '<div class="Shortcut">';
    html += '<ul class="Shortcut-list">';
    html += '<li class="Shortcut-listItem" data-index="0">';
    html += '<a class="Shortcut-listItem-link" href="./user.html" target="_blank">';
    html += '<i class="is-center"></i>';
    html += '<p>个人中心</p>';
    html += '</a>';
    html += '</li>';
    html += '<li class="Shortcut-listItem" data-index="1">';
    html += '<a class="Shortcut-listItem-link" href="./follow.html" target="_blank">';
    html += '<i class="is-attention"></i>';
    html += '<p>我的关注</p>';
    html += '</a>';
    html += '</li>';
    html += '</ul>';
    html += '</div>';
    html += '<div class="CloudGameLink">';
    html += '<a href="javascript:clickDown();" target="_self" class="CloudGameLink-text">下载手机app</a>';
    html += '</div>';
    html += '<div class="Exit">';
    html += '<span class="Exit-btn" onclick="logout()"><i></i>登出</span>';
    html += '</div>';
    html += '</div>';
    html += '</div>';
    html += '';
    html += '';
    return html;
}


function loginLoseDiv() {
    var html = '';
    html += '<div class="public-DropMenu-drop">';
    html += '<div class="public-DropMenu-drop-main">';
    html += '<div class="UnLogin-content">';
    html += '<h3>登录之后可以</h3>';
    html += '<ul class="UnLogin-privilege">';
    html += '<li><i class="UnLogin-privilegeIcon is-barrage"></i>发弹幕</li>';
    html += '<li><i class="UnLogin-privilegeIcon is-hd"></i>看高清</li>';
    html += '<li><i class="UnLogin-privilegeIcon is-follow"></i>关注主播</li>';
    html += '</ul>';
    html += '<a class="UnLogin-btn" href="javascript:;">登录</a>';
    html += '<a class="UnLogin-btn">注册</a>';
    html += '</div>';
    html += '</div>';
    html += '<i></i>';
    html += '</div>';
    return html;
}






// 保存cookie
function setCookie(key, value) {
    document.cookie = "" + key + "=" + value + ";expires=Thu, 18 Dec 2043 12:00:00 GMT";
}
// 读取cookie
function getCookie(key) {
    var cookie = document.cookie;
    cookie = cookie.replace(/ /g, "");
    if (cookie !== "" && cookie !== null) {
        var cookies = cookie.split(";");
        for (var i = 0; i < cookies.length; i++) {
            if (cookies[i].split("=")[0] === key) {
                return cookies[i].split("=")[1];
            }
        }
    }
    return "";
}

// 读取url属性
function getQueryString(name) {
    var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
    var r = window.location.search.substr(1).match(reg);
    if (r !== null) {
        return unescape(r[2]);
    }
    return null;
}

