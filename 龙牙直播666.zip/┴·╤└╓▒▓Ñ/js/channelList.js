window.onload = function () {
    initFunc(none);
    getType();
};


$(document).ready(function () {
    $("#nav .layout-Module-label").click(function () {
        var no = $(this).index();
        changer($(this), no);
    });
});

function getType() {
    debugger
    var type = getQueryString("type");
    if (type === null) {
        type = 0;
    }
    changer($("#nav .layout-Module-label").eq(type), type);
}

function findVideoChannelList(json, d) {

    var html = "";
    for (var i = 0; i < json.length; i++) {
        var item = json[i];
        var cimg = (item.cover === "" || item.cover === undefined) === true ? item.cimg : item.cover;
        html += channelListWindow(item.no, item.bigname, cimg, item.img, item.title, item.aname, item.hot);
    }
    d.html(html);
}

function changer(d, no) {
    debugger
    no = parseInt(no);
    $(".layout-Module-label").removeClass("is-active");
    d.addClass("is-active");
    $("#nav > h2").text(d.children("strong").text());
    getVideoInfo(findVideoChannelList, "findVideoList", no, $("#channelUl"));
    $("#js-header ul li").removeClass("active");
    $("#js-header ul li").eq(no + 2).addClass("active");
}