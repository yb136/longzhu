
window.onload = function () {
    initFunc(none);
    
    // 获得推荐视频
    getRecommendVideo();
    // 获得分类视频
    getVideoInfo(videoHotToHtml, "getHotVideo",  0, $("#lazyModule1"));
    getVideoInfo(videoHotToHtml, "bigVideoList", 1, $("#lazyModule2"));
    getVideoInfo(videoHotToHtml, "bigVideoList", 2, $("#lazyModule3"));
    getVideoInfo(videoHotToHtml, "bigVideoList", 3, $("#lazyModule4"));
    getVideoInfo(videoHotToHtml, "bigVideoList", 4, $("#lazyModule5"));
};

function domInit() {
    $("#layout-Slide-nav").click(function () {

    });
}


function videoHotToHtml(json, d) {
    var html = "";
    for (var i = 0; i < json.length && i < 10; i++) {
        var item = json[i];
        var cimg = (item.cover === "" || item.cover === undefined) === true ? item.cimg : item.cover;
        html += liveWindow(item.no, item.bigname, cimg, item.img, item.title, item.aname, item.hot);
    }
    d.parent().find(".RoomList-liveNum").text(json.length);
    d.html(html);
}


function recommendVideo() {
    var html = '';
    html += '<div class="Slider-flashTab Slider-flashTabCover">';
    html += '<div class="Slider-flashTabImg">';
    html += '<div class="LazyLoad is-visible DyImg Slider-flashTabImgIn">';
    html += '<img src="./files/270c4cf713a4e1bc78646574bf221097.jpg" class="DyImg-content is-normal " />';
    html += '</div>';
    html += '<div class="Slider-flashTabHover"></div>';
    html += '</div>';
    html += '</div>';
    return html;
}

function getRecommendVideo() {

    $.ajax({
        url: contentUlr + "/AjaxServer/ServerAjaxData.aspx",
        type: "POST",
        loading: true,
        dataType: "json",
        data: {
            action: "getIndexFiveLive"
        },
        success: function (json) {
            debugger
            if (json.length > 0) {
                var isPlayer = false;
                var divs = $("#layout_right_video > div");
                for (var i = 0; i < divs.length && i < json.length; i++) {
                    var item = json[i];
                    var div = divs.eq(i);
                    var no = item.no;
                    if (no > 0) {
                        div.find("img").attr("src", manageurl + item.mimg);
                        div.attr("onclick", "getLiveSource(" + item.no + ", this)");
                        div.attr("data-live", item.no);
                    } else {
                        div.find("img").attr("src", manageurl + item.mimg);
                        div.attr("onclick", "");
                        div.attr("data-live", item.no);
                    }
                    if (!isPlayer) {
                        getLiveSource(item.no, div[0]);
                        isPlayer = true;
                    }
                }
            }
        },
        error: function (e) {

        }

    });
}

// 获得视频源
function getLiveSource(no, dom) {
    // 进入直播间div链接切换
    $("#videonext a").attr("href","javascript:;").attr("target", "_self");
    // 推荐视频css切换 选择框、遮盖层。。。
    var ds = $("#layout-Slide-nav > div.Slider-flashTab");
    ds.addClass("Slider-flashTabCover");
    ds.find(".Slider-block,.Slider-clickPoint").remove();

    var d = $(dom);
    d.removeClass("Slider-flashTabCover");
    d.children(".Slider-flashTabImg").append('<div class="Slider-flashTabHover Slider-block"></div>');
    d.append("<div class=\"Slider-clickPoint\"></div>");
    
    $.ajax({
        url: "/AjaxServer/ServerAjaxData.aspx",
        type: "POST",
        loading: true,
        data: {
            action: "findPullSource",
            ano: no
        },
        success: function (source) {
            if (source === "-1") {
                //layer.msg("当前直播间已被管理员关闭");
                return;
            }
            // 进入直播间div链接切换
            $("#videonext a").attr("href", "./live.html?live=" + no).attr("target", "_self");
            var videoObject = {
                container: '#video', //容器的ID或className
                variable: 'player',//播放函数名称
                autoplay: true,
                live: true,
                video: source
            };
            var player = new ckplayer(videoObject);
        },
        error: function (e) {}
    });
}